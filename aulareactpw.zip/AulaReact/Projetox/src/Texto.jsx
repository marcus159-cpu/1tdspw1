import "./Texto.css";

function Texto() {
  return (
    <>
      <div>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Corrupti
          tempore voluptatibus dolor debitis voluptatem ducimus expedita
          architecto explicabo dolores dolore?
        </p>
      </div>
    </>
  );
}

export default Texto;
