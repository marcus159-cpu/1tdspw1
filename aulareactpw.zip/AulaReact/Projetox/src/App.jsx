import "./App.css";
import { useState } from "react";

function App() {
  const [mensage, setMessage] = useState("Mensagem inicial");

  return (
    <>
      <div>
        <h1>{mensage}</h1>
        <button
          onClick={() => {
            setMessage("Fui Clickado");
          }}
        >
          Click
        </button>
      </div>
    </>
  );
}

export default App;
